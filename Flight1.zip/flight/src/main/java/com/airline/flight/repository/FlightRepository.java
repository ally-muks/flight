package com.airline.flight.repository;

import org.springframework.data.repository.CrudRepository;

import com.airline.flight.entity.Flight;

public interface FlightRepository extends CrudRepository<Flight,Long>{
    Flight findByFlightNumber(String flightNumber);

}

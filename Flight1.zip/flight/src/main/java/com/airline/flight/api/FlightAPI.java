package com.airline.flight.api;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.flight.dto.FlightDTO;
import com.airline.flight.dto.NotificationDTO;
import com.airline.flight.service.FlightService;
import com.airline.flight.service.NotificationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/flights")
public class FlightAPI {
    @Autowired
    private FlightService flightService;

    @Autowired
    private NotificationService notificationService;
    @Autowired
    private Environment environment;

    @GetMapping("/{flightNumber}")
    public ResponseEntity<FlightDTO>  getFlightStatus(@PathVariable String flightNumber) {
        FlightDTO flight= flightService.getFlightStatus(flightNumber);
        return new ResponseEntity<>(flight,HttpStatus.OK);
    }
    @PostMapping("/update")
    public ResponseEntity updateFlightStatus(@RequestBody FlightDTO flightDTO) {
        flightService.updateFlightStatus(flightDTO);
        String message=environment.getProperty("API.UPDATE_SUCCESS");
        NotificationDTO notificationDTO = new NotificationDTO();
        notificationDTO.setFlightNumber(flightDTO.getFlightNumber());
        notificationDTO.setMessage("Flight status updated: " + flightDTO.getStatus());
        notificationDTO.setType("UPDATE");
        notificationService.sendNotification(notificationDTO);
        return new ResponseEntity<>(message,HttpStatus.ACCEPTED);
    }
    @PostMapping("/addFlight")
    public ResponseEntity<String> addFlight(@Valid @RequestBody FlightDTO flightDTO){
    	String id=flightService.addFlight(flightDTO);
    	String message=environment.getProperty("API.INSERT_SUCCESS")+" "+ id;
    	return new ResponseEntity<>(id, HttpStatus.CREATED);
    }

}

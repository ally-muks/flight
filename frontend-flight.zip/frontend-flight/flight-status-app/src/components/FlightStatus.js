// src/components/FlightStatus.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';

const FlightStatus = () => {
  const [flightNumber, setFlightNumber] = useState('');
  const [flight, setFlight] = useState(null);
  const [status, setStatus] = useState('');
  const [gate, setGate] = useState('');

  const getFlightStatus = async () => {
    try {
      const response = await axios.get(`/api/flights/${flightNumber}`);
      setFlight(response.data);
      setStatus(response.data.status);
      setGate(response.data.gate);
    } catch (error) {
      console.error('Error fetching flight status', error);
    }
  };

  const updateFlightStatus = async () => {
    try {
      const updatedFlight = {
        id: flight.id,
        flightNumber: flight.flightNumber,
        status,
        gate,
      };
      await axios.post('/api/flights/update', updatedFlight);
      getFlightStatus();
    } catch (error) {
      console.error('Error updating flight status', error);
    }
  };

  return (
    <div className="flight-status">
      <h1>Flight Status</h1>
      <div>
        <input
          type="text"
          value={flightNumber}
          onChange={(e) => setFlightNumber(e.target.value)}
          placeholder="Enter flight number"
        />
        <button onClick={getFlightStatus}>Get Flight Status</button>
      </div>
      {flight && (
        <div>
          <h2>Flight Number: {flight.flightNumber}</h2>
          <div>
            <label>Status:</label>
            <input
              type="text"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            />
          </div>
          <div>
            <label>Gate:</label>
            <input
              type="text"
              value={gate}
              onChange={(e) => setGate(e.target.value)}
            />
          </div>
          <button onClick={updateFlightStatus}>Update Flight Status</button>
        </div>
      )}
    </div>
  );
};

export default FlightStatus;

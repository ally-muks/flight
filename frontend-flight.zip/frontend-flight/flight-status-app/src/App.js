// src/App.js

import React from 'react';
import FlightStatus from './components/FlightStatus';
import './App.css';

function App() {
  return (
    //<div className='back'>
    <div className="App">
      
      <FlightStatus />
    </div>
    //</div>
  );
}

export default App;

package com.airline.flight.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.flight.dto.FlightDTO;
import com.airline.flight.entity.Flight;
import com.airline.flight.repository.FlightRepository;

@Service
public class FlightService {
	@Autowired
    private FlightRepository flightRepository;

    public FlightDTO getFlightStatus(String flightNumber) {
        Flight flight = flightRepository.findByFlightNumber(flightNumber);
        if (flight != null) {
            FlightDTO flightDTO = new FlightDTO();
            flightDTO.setId(flight.getId());
            flightDTO.setFlightNumber(flight.getFlightNumber());
            flightDTO.setStatus(flight.getStatus());
            flightDTO.setGate(flight.getGate());
            return flightDTO;
        }
        return null;
    }
    public void updateFlightStatus(FlightDTO flightDTO) {
        Flight flight = flightRepository.findById(flightDTO.getId()).orElse(null);
        if (flight != null) {
            flight.setStatus(flightDTO.getStatus());
            flight.setGate(flightDTO.getGate());
            flightRepository.save(flight);
        }
    }
}

package com.airline.flight.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.flight.dto.FlightDTO;
import com.airline.flight.dto.NotificationDTO;
import com.airline.flight.service.FlightService;
import com.airline.flight.service.NotificationService;

@RestController
@RequestMapping("/api/flights")
public class FlightAPI {
    @Autowired
    private FlightService flightService;

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/{flightNumber}")
    public FlightDTO getFlightStatus(@PathVariable String flightNumber) {
        return flightService.getFlightStatus(flightNumber);
    }
    @PostMapping("/update")
    public void updateFlightStatus(@RequestBody FlightDTO flightDTO) {
        flightService.updateFlightStatus(flightDTO);
        NotificationDTO notificationDTO = new NotificationDTO();
        notificationDTO.setFlightNumber(flightDTO.getFlightNumber());
        notificationDTO.setMessage("Flight status updated: " + flightDTO.getStatus());
        notificationDTO.setType("UPDATE");
        notificationService.sendNotification(notificationDTO);
    }

}

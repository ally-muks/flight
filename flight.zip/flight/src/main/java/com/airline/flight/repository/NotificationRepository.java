package com.airline.flight.repository;

import org.springframework.data.repository.CrudRepository;

import com.airline.flight.entity.Notification;

public interface NotificationRepository extends CrudRepository<Notification, Long>{

}

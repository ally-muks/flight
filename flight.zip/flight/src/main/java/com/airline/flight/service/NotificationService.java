package com.airline.flight.service;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.flight.dto.NotificationDTO;
import com.airline.flight.entity.Notification;
import com.airline.flight.repository.NotificationRepository;
@Service
public class NotificationService {
	 @Autowired
	    private NotificationRepository notificationRepository;

	    @Autowired
	    private RabbitTemplate rabbitTemplate;

	    public void sendNotification(NotificationDTO notificationDTO) {
	        Notification notification = new Notification();
	        notification.setFlightNumber(notificationDTO.getFlightNumber());
	        notification.setMessage(notificationDTO.getMessage());
	        notification.setType(notificationDTO.getType());
	        notification.setRecipient(notificationDTO.getRecipient());
	        notificationRepository.save(notification);
	        rabbitTemplate.convertAndSend("flightStatusQueue", notificationDTO);

	        // Code to send notification via SMS, email, etc.

	    }
}
